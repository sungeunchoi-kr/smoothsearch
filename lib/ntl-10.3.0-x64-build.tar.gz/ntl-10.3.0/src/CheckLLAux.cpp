
void touch(unsigned long& x) { }
void touch(long& x) { }

