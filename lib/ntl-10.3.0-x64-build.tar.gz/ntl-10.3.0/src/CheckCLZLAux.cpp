
void touch(unsigned long& x) { }
